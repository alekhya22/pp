package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Bank")
public class BankData implements Serializable{

	@Column(name="name")
		String name;
	@Column(name="mobileNo")
		long mobileno;
	@Id
	@Column(name="accNo")
		int accNo;
	@Column(name="balance")
		float balance;

		public BankData(String name, long mobileno, int accNo, float balance) {
			super();
			this.name = name;
			this.mobileno = mobileno;
			this.accNo = accNo;
			this.balance = balance;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public long getMobileno() {
			return mobileno;
		}

		public void setMobileno(long mobileno) {
			this.mobileno = mobileno;
		}

		public int getAccNo() {
			return accNo;
		}

		public void setAccNo(int accNo) {
			this.accNo = accNo;
		}

		public float getBalance() {
			return balance;
		}

		public void setBalance(float balance) {
			this.balance = balance;
		}

		
	}

