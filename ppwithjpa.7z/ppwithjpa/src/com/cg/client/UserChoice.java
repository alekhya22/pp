package com.cg.client;

import java.util.Scanner;



public class UserChoice {
	public static void main(String[] args) {
		   Modules module=new Modules();
			Scanner scan=new Scanner(System.in);
			char option;
			int choice;
			while(true) {
				System.out.println("Enter the option\n1.Create Account");
				System.out.println("\n2.Show Balance\n3.Deposit\n4.WithDraw\n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit");
		        choice=scan.nextInt();
		        switch(choice) {
		        case 1:module.CreateAccount();
		        	break;
		        case 2:module.showBalance();
		        	break;
		        case 3:module.deposit();
		        	break;
		        case 4:module.withdraw();
		        	break;
		        case 5:module.transfer();
		        	break;
		        case 6:module.printTransaction();
		        	break;
		        case 7:
		        	return;
		        }
			
			}
		}
		}

