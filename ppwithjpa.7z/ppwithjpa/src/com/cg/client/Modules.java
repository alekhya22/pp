package com.cg.client;

import java.util.Random;
import java.util.Scanner;

import com.cg.bean.BankData;
import com.cg.service.BankService;

public class Modules {
	Scanner scan = new Scanner(System.in);
	BankService bankService = new BankService();
	public void CreateAccount() {
	

		

		int res = 1;
		String name;
		long mobileno;
		try {
			System.out.println("Enter name: ");
			do {
				if (res == 0) {
					System.out.println("name should contain only alphabets enter again ");
				}
				name = scan.next();
				res = bankService.checkName(name);

			} while (res == 0);

			res = 1;
			System.out.println("Enter mobile no: ");
			do {
				if (res == 0) {
					System.out.println("enter valid mobile no");
				}
				mobileno = scan.nextLong();
				res = bankService.checkMobNo(mobileno);

			} while (res == 0);
			Random rand = new Random();
			int accNo = rand.nextInt(200000) + 123456;

			System.out.println("Enter Balance");
			float balance = scan.nextFloat();
			BankData bankData = new BankData(name, mobileno, accNo, balance);
			bankService.createAccount(bankData);
			System.out.println("Account created with account number" + accNo);
		} catch (Exception e) {
			System.out.println("type mismatch exception occured");
		}

	}

	

	public void showBalance() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Enter Account Number:");
			int accNo = scan.nextInt();
			float balance = bankService.showBalance(accNo);
			if (balance == 0) {
				System.out.println("please create the account");
			} else {

				System.out.println("the balance is:" + balance);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void deposit() {
		// TODO Auto-generated method stub

	}

	public void withdraw() {
		// TODO Auto-generated method stub

	}

	public void transfer() {
		// TODO Auto-generated method stub

	}

	public void printTransaction() {
		// TODO Auto-generated method stub

	}

}
