package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.bean.BankData;

public class BankDao {
	private EntityManager entityManager;
	public BankDao() {
		entityManager=JPAutil.getEntityManager();
	}
public void  createAccount(BankData bankData) {
	entityManager.persist(bankData);
}
public void beginTransaction() {
	// TODO Auto-generated method stub
	entityManager.getTransaction().begin();
	
}
public void commitTransaction() {
	entityManager.getTransaction().commit();
}
public float showBalance(int accNo) {
	// TODO Auto-generated method stub
	int bal=0;
	Query query = entityManager.createQuery("Select b.accNo from BankData b");  
	 List<Float> list =query.getResultList();  
	for(float s:list){
		if(accNo==s) {
		query=entityManager.createQuery("select b.balance from BankData b where b.accNo=accNo");
	 bal=query.getFirstResult();
		
	 }
		
	}
	return bal;	
}
}
