package com.cg.service;

import java.util.regex.Pattern;

import com.cg.bean.BankData;
import com.cg.dao.BankDao;

public class BankService {
	BankDao bankDao=new BankDao();
	public int checkName(String name) {
		if (Pattern.matches("([A-Z])*([a-z])*", name)) {
return 1;
		}
		else
			return 0;
	}
//
//	public int validateAccount(int accNo) {
//		if (bankDao.getMaps().containsKey(accNo))
//			return 1;
//		else
//			return 0;
//	}

	public int checkMobNo(long mobileno) {
		if(toString().valueOf(mobileno).length()!=10)
			return 0;
		else 
			return 1;
		
	}

	public void createAccount(BankData bankData) {
		// TODO Auto-generated method stub
		bankDao.beginTransaction();
		bankDao.createAccount(bankData);
		bankDao.commitTransaction();
		
		
	}

	public float showBalance(int accNo) {
		// TODO Auto-generated method stub
float balance=bankDao.showBalance(accNo);
		return balance;
	}
}
