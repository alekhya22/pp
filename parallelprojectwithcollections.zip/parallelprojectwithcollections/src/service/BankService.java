package service;

import java.util.regex.Pattern;

import bean.BankData;
import dao.BankDao;

public class BankService {
	BankData bankData;
	BankDao bankDao = new BankDao();

	public void createAccount(BankData bankData) {
		bankDao.createAccount(bankData);
	}

	public float showBalance(int accNo) {
		float bal = 0;
		if (bankDao.getMaps().isEmpty()) {

			return 0;
		}

		else if (bankDao.getMaps().containsKey(accNo)) {

			bal = bankDao.getMaps().get(accNo).getBalance();

		}
		return bal;

	}

	public float deposit(int accNo, float deptAmt) {
		float finalAmt = bankDao.getMaps().get(accNo).getBalance() + deptAmt;
		bankDao.getMaps().get(accNo).setBalance(finalAmt);
		return finalAmt;
	}

	public float withdraw(int accNo, float withdraw) {
		if (withdraw > bankDao.getMaps().get(accNo).getBalance())
			return -1;

		else
			return bankDao.getMaps().get(accNo).getBalance() - withdraw;
		

	}
	public int transfer(int sAccNo,int dAccNo,float tAmt) {
		if(bankDao.getMaps().get(sAccNo).getBalance()<tAmt) {
			return -1;
		}
		else {
			float samt=bankDao.getMaps().get(sAccNo).getBalance();
			float fsamt=samt-tAmt;
			bankDao.getMaps().get(sAccNo).setBalance(fsamt);
			float damt=bankDao.getMaps().get(dAccNo).getBalance();
			float fdamt=damt+tAmt;
			bankDao.getMaps().get(dAccNo).setBalance(fdamt);
			return 1;
		}
		
		
	}

	public int checkName(String name) {
		if (Pattern.matches("([A-Z])*([a-z])*", name)) {
return 1;
		}
		else
			return 0;
	}

	public int validateAccount(int accNo) {
		if (bankDao.getMaps().containsKey(accNo))
			return 1;
		else
			return 0;
	}

	public int checkMobNo(long mobileno) {
		if(toString().valueOf(mobileno).length()!=10)
			return 0;
		else 
			return 1;
		
	}
}
