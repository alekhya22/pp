package dao;

import java.util.HashMap;

import bean.BankData;

public class BankDao {
	HashMap<Integer,BankData> maps=new HashMap<Integer,BankData>();
	
public HashMap<Integer, BankData> getMaps() {
		return maps;
	}



public void createAccount(BankData bankData) {
	maps.put(bankData.getAccNo(), bankData);
	
}

}
