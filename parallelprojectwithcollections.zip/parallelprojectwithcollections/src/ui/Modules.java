package ui;

import java.util.Random;
import java.util.Scanner;

import bean.BankData;
import service.BankService;

public class Modules {
	BankService bankService = new BankService();

	Scanner scan = new Scanner(System.in);

	public void CreateAccount() {
		int res = 1;
		String name;
		long mobileno;
		try {
			System.out.println("Enter name: ");
			do {
				if (res == 0) {
					System.out.println("name should contain only alphabets enter again ");
				}
				name = scan.next();
				res = bankService.checkName(name);

			} while (res == 0);

			res = 1;
			System.out.println("Enter mobile no: ");
			do {
				if (res == 0) {
					System.out.println("enter valid mobile no");
				}
				mobileno = scan.nextLong();
				res = bankService.checkMobNo(mobileno);

			} while (res == 0);
			Random rand = new Random();
			int accNo = rand.nextInt(200000) + 123456;

			System.out.println("Enter Balance");
			float balance = scan.nextFloat();
			BankData bankData = new BankData(name, mobileno, accNo, balance);
			bankService.createAccount(bankData);
			System.out.println("Account created with account number" + accNo);
		} catch (Exception e) {
			System.out.println("type mismatch exception occured");
		}

	}

	public void showBalance() {
		try {
			System.out.println("Enter Account Number:");
			int accNo = scan.nextInt();
			float balance = bankService.showBalance(accNo);
			if (balance == 0) {
				System.out.println("please create the account");
			} else {

				System.out.println("the balance is:" + balance);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void deposit() {
		try {
			System.out.println("enter the account no");
			int accNo = scan.nextInt();
			int res = bankService.validateAccount(accNo);
			if (res == 1) {
				System.out.println("Enter the amount to be deposited");
				float depAmt = scan.nextFloat();
				float amt = bankService.deposit(accNo, depAmt);
				System.out.println("your account balance is" + amt);
			} else {
				System.out.println("account doesnot exist");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void withdraw() {
		try {
			System.out.println("enter the account number");
			int accNo = scan.nextInt();
			int res = bankService.validateAccount(accNo);
			if (res == 1) {
				System.out.println("enter the amount to withdraw");
				float withdraw = scan.nextFloat();
				float rembal = bankService.withdraw(accNo, withdraw);
				if (rembal == -1) {
					System.out.println("insufficient balance");
				} else {
					System.out.println("the balance in the account after withdrawal is" + rembal);
				}
			} else {
				System.out.println("account doesnot exist");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void transfer() {
		try {
			System.out.println("enter the source account number");
			int sAccNo = scan.nextInt();
			int res = bankService.validateAccount(sAccNo);
			if (res == 1) {
				System.out.println("enter the destination account number");
				int dAccNo = scan.nextInt();
				res = bankService.validateAccount(dAccNo);
				if (res == 1) {
					System.out.println("enter the amount to transfer");
					float tAmt = scan.nextFloat();
					res = bankService.transfer(sAccNo, dAccNo, tAmt);
					if (res == 1) {
						System.out.println("amount succesfully transfered");
					} else {
						System.out.println("You donnot have sufficient amount");
					}
				} else {
					System.out.println("destination account doesnot exist");
				}
			} else {
				System.out.println("source account does not exist");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void printTransaction() {

	}
}
