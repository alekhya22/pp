package bean;

public class BankData {
	String name;
	long mobileno;
	int accNo;
	float balance;

	public BankData(String name, long mobileno, int accNo, float balance) {
		super();
		this.name = name;
		this.mobileno = mobileno;
		this.accNo = accNo;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	
}
