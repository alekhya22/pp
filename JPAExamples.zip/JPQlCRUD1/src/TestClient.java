import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class TestClient {

	public static void main(String[] args) {

EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPQLCRUD");  
       EntityManager em=emf.createEntityManager();  
       em.getTransaction().begin(); 
//insert

/*Employee e=new Employee(123,"suresh",10000);
Employee e1=new Employee(124,"naresh",20000);
Employee e2=new Employee(125,"ramesh",30000);
Employee e3=new Employee(126,"suresh",40000);
em.persist(e);
em.persist(e1);
em.persist(e2);
em.persist(e3);*/
//fetch
     /*  TypedQuery<Employee> q2 =
    	em.createQuery("select c from Employee c", Employee.class);
   			List<Employee> l1=q2.getResultList();
   			for(Employee e1:l1)
   			{
   				System.out.println(e1.getEid());
   				System.out.println(e1.getEname());//...all 
   			}*/
Query q1 = em.createQuery("select c from Employee c");

			List<Employee> l=	q1.getResultList();
			for(Employee e:l)
			{
				System.out.print(e.getEid());
				System.out.print("\t" +e.getEname());
				System.out.print("\t" +e.getEsal());
				System.out.println();
			}
/*//update
Query q = em.createQuery( "update Employee set esal=25000 where esal<20000");  
           q.executeUpdate();
//delete
Query q2 = em.createQuery( "delete from Employee where empid=123");  
 q2.executeUpdate();  
           
         
  Query query = em.createQuery("select MAX(emp.esal) FROM Employee emp");
    		     int maxsal =(int)query.getSingleResult();
           System.out.println(maxsal);*/
em.getTransaction().commit(); 

em.close();  
emf.close();  

	}

}

