package com.pdw.entities;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("1-1uni");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		/*Student student = new Student();
		student.setName("akash reddy");
		Address homeAddress = new Address();
		homeAddress.setStreet("MG Road");
		homeAddress.setCity("Hyderabad");
		homeAddress.setState("Telangana");
		homeAddress.setZipCode("500074");
		
		//inject address into student
		student.setAddress(homeAddress);
		
		//persist only student, no need to persist Address explicitly
		em.persist(student);*/
	
	
		Address stu=em.find(Address.class,4);
			System.out.println(stu);
			em.remove(stu);
		em.getTransaction().commit();
		System.out.println("removed one student with address to database.");
		em.close();
		factory.close();
	}
}
