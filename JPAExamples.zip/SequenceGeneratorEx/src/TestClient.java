import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestClient {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("a");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		Employee e1 = new Employee();
		//e1.setEid(125);
		e1.setEname("suresh");
		e1.setEsal(1234);
		em.persist(e1);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}
}
