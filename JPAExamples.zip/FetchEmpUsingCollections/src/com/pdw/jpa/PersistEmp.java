package com.pdw.jpa;


import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class PersistEmp {  
     
   public static void main(String args[])  
   {  
EntityManagerFactory emf=Persistence.createEntityManagerFactory("FetchEmpUsingCollections");  
       EntityManager em=emf.createEntityManager(); 
       
     /*  em.getTransaction().begin();
       
       Employee emp=new Employee(123, "suresh", 12000, "hyderabad");
       
       em.persist(emp);
       em.getTransaction().commit();
       System.out.println("inserted");*/
       
       
    Query q= em.createQuery("select e from Employee e");

    		List<Employee> l=	q.getResultList();
    		
    		for(Employee emp:l)
    		{
    			System.out.println(emp.getEid());
    			System.out.println(emp.getEname());
    			System.out.println(emp.getEsal());
    			System.out.println(emp.getEadd());
    		}
    
    
    
    
       em.close();  
       emf.close();  
         
   }  
} 